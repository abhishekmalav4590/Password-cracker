import hashlib
import time
from itertools import product
import string

def hash_password(password, algorithm):
    if algorithm == "md5":
        return hashlib.md5(password.encode()).hexdigest()
    elif algorithm == "sha1":
        return hashlib.sha1(password.encode()).hexdigest()
    elif algorithm == "sha256":
        return hashlib.sha256(password.encode()).hexdigest()

def dictionary_attack(hash_to_crack, algorithm, wordlist):
    with open(wordlist, "r") as file:
        for word in file:
            word = word.strip()
            hashed_word = hash_password(word, algorithm)
            if hashed_word == hash_to_crack:
                return word
    return None

def brute_force_attack(hash_to_crack, algorithm, max_length=4):
    chars = string.ascii_lowercase + string.digits
    for length in range(1, max_length + 1):  
        for attempt in product(chars, repeat=length):
            word = ''.join(attempt)
            hashed_word = hash_password(word, algorithm)
            if hashed_word == hash_to_crack:
                return word
    return None

def crack_password(hash_to_crack, algorithm, wordlist):
    start_time = time.time()
    print(f"Cracking hash: {hash_to_crack} using {algorithm}...")

    # Try dictionary attack
    cracked = dictionary_attack(hash_to_crack, algorithm, wordlist)
    if cracked:
        end_time = time.time()
        print(f"[SUCCESS] Password found: {cracked} (Time: {end_time - start_time:.2f}s)")
        return cracked

    # Try brute force attack
    print("Dictionary attack failed, attempting brute force...")
    cracked = brute_force_attack(hash_to_crack, algorithm)
    if cracked:
        end_time = time.time()
        print(f"[SUCCESS] Password found: {cracked} (Time: {end_time - start_time:.2f}s)")
        return cracked

    print("[FAIL] Password not found.")
    return None

# Read hashed passwords from file
hashes = open("hashes.txt", "r").read().splitlines()

# Specify the hashing algorithm and wordlist file
algorithm = "md5"
wordlist = "wordlist.txt"

for hash_to_crack in hashes:
    crack_password(hash_to_crack, algorithm, wordlist)
